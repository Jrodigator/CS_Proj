class button:
        def __init__(self):
            self.__init__pygame()
            #self.rect=