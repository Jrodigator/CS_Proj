Hive Invaders - By Jared, Ross & Tiaan 

Ross's Sources

Game music - (2022) Internet Archive [Preprint]. Vp1985. Available at: https://archive.org/details/doom-eternal-22.-the-only-thing-they-fear-is-you (Accessed: March 31, 2023). 
Title Screen Font - JDGraphics (2022) Minecraft Font, Font Space. JDGraphics. Available at: https://www.fontspace.com/minecraft-font-f28180 (Accessed: March 11, 2023). 
Background Main Menu - Jihane37 (no date) Bees Cartoon Holding Flower And A Beehive With Forest Background, Pinterest. Dreamstime Stock Photos. Available at: https://za.pinterest.com/pin/bees-cartoon-holding-flower-and-a-beehive-with-forest-background-illustration-o-spon-holding-flower--820499625849040354/ (Accessed: March 31, 2023). 

Jared's Sources 

Custom Sprites (Bee, Stinger, Ant, Bird, Bear and Lives) made by me. ( Made With https://www.piskelapp.com)
Background Image made as a shader with c++ and OpenGL -> inspiration from ShaderToy.com

Required Fetures list:

- Title Screen (with Instructions)
- Drawing Shooter and Turrent (Bee and Stinger)
- Drawing enemies
- Turret Shooting
- Bullets move at aim angle
- Multiple Bullets Possible
- Shooting has a Cooldown
- Enemies Move and Decend
- Player can move left right 
- Player cant leave screen 
- Bullets kill enemies and gets deleted on hit
- Score increases on enemy death or hit
- Lose lifes when touching enemy or enemy projectile
- Game ends when lives are out or all enemies defeated
- restart Possible after death
- Quit Key (Q)

Additional Features list:

- Improved graphics
	- Many improvements, some noteworthy ones include
		- Selfmade graphics
		- Bee follows direction of mouse
		- Bullets direction is the same as the direction they were shot in
- Game sound/music
- Highscore Board (Leader Board)
- Multiple Levels
	- Differing enemies on each level
		- Differ in number and hit points and movements and behaviour
			- Bear can summon enemies
	- Level Select
	- 'Invader' count on each level
	- Once level 5 is passed, theres an option to enter an endless mode or endless level
- Additional Lives
- Enemies Counter Attack
	- Based on enemy type
- Bunkers that vary depending on level and that get damaged and are animated to show damage
- Powerups
	- 6 powerups or "jellies" in total
	- Red gives the basic bullet at 0.5 damage
	- Grey activates doubleshot at 1 damage
	- Blue gives a blue bullet that does 1.5x damage
	- Green restores 1 heart
	- Pink rebuilds bunkers with +1Hp
	- Yellow increases score
- Varing Enemy Hitpoints
- Different missile types 
- Different Enemy types 
- Pause menu